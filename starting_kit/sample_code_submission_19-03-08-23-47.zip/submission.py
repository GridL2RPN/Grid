import pypownet.agent
import pypownet.environment
import numpy as np

class Submission(pypownet.agent.Agent):
    def __init__(self, environment):
        super().__init__(environment)
        self.verbose = True
        
    def act(self, observation):
        assert isinstance(observation, pypownet.environment.Observation)
        action_space = self.environment.action_space
        
        action = action_space.get_do_nothing_action() #We initialise an empty action
            
        lines_list = observation.get_lines_capacity_usage() #We monitor how charged the lines of our power network are
        
        #Without the following line, our grid would never be turned on resulting in our agent being a do_nothing agent
        action_space.set_lines_status_switch_from_id(action=action,line_id=np.random.randint(action_space.lines_status_subaction_length),new_switch_value=1)
        
        #Here, if a line's charge exceeds 80% of it's capacity, we turn it off
        for i in range(action_space.lines_status_subaction_length - 1):
            if lines_list[i] > 0.8:
                action_space.set_lines_status_switch_from_id(action=action,line_id=i,new_switch_value=1)
        
        #These are testing variables, allowing us to monitor the actions we take during the steps
        """idList = np.arange(action_space.lines_status_subaction_length)
        line_status = action_space.get_lines_status_switch_from_id(action=action,line_id=idList)
        print(line_status)"""
        
        assert self.environment.action_space.verify_action_shape(action)
        
        return action
